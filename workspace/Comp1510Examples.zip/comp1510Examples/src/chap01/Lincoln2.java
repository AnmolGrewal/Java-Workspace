package chap01;

/**
 * Demonstrates a poorly formatted, though valid, program.
 * Many Checkstyle errors.
 * 
 * @author Lewis
 * @author Loftus
 * @version 1
 */
public class Lincoln2{public static void main(String[]args){
System.out.println("A quote by Abraham Lincoln:");
System.out.println("Whatever you are, be a good one.");}}
